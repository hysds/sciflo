import random

def getRandom():
	return random.random()
