import time
import testModule2

print "Random number is %s at epoch %s." % (testModule2.getRandomNum(),
time.time())
